# coc_to_yolo > 2024-11-06 10:52am
https://universe.roboflow.com/san-hanona/coc_to_yolo

Provided by a Roboflow user
License: CC BY 4.0

